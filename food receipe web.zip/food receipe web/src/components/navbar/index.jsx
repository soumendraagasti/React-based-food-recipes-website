import { NavLink } from "react-router-dom";
import "./NavbarStyles.css"; // assuming you use external css
import { useContext } from "react";
import { GlobalContext } from "../context";

const Navbar = () => {
  const { searchParam, setSearchParam, handleSubmit } =
    useContext(GlobalContext);

  console.log(searchParam);
  return (
    <nav className="custom-container">
      <h2 className="custom-heading">
        <NavLink to={"/"}>FoodReceipe</NavLink>
      </h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="search"
          placeholder="Enter item..."
          className="custom-input"
          value={searchParam}
          onChange={(event) => setSearchParam(event.target.value)}
        />
      </form>
      <ul className="yourClasses">
        <h3>
          <NavLink to={"/"} className="yourClass">
            Home
          </NavLink>
        </h3>
        <h3>
          <NavLink to={"/favorites"} className="yourClass">
            Favorites
          </NavLink>
        </h3>
      </ul>
    </nav>
  );
};

export default Navbar;
