import { useContext } from "react";
import { GlobalContext } from "../../components/context";
import ReceipeItem from "../../components/receipe-item";

const Favorites = () => {
  const { favoritsList } = useContext(GlobalContext);

  return (
    <div className="py-8 container mx-auto flex flex-wrap justify-center gap-10">
      {favoritsList && favoritsList.length > 0 ? (
        favoritsList.map((item) => <ReceipeItem item={item} />)
      ) : (
        <div>
          <p className="text-center text-black font-extrabold text-xl lg:text-4xl">
            Nothing is added in favorites
          </p>
        </div>
      )}
    </div>
  );
};

export default Favorites;
