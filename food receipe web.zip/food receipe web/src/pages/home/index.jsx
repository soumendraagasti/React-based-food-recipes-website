import { useContext } from "react";
import { GlobalContext } from "../../components/context";
import ReceipeItem from "../../components/receipe-item";
import "./HomeStyles.css";

const Home = () => {
  const { recipeList, loading } = useContext(GlobalContext);
  if (loading) return <div>Loading.. Please wait.</div>;
  return (
    <div className="py-8 container mx-auto flex flex-wrap justify-center gap-10">
      {recipeList && recipeList.length > 0 ? (
        recipeList.map((item) => <ReceipeItem item={item} />)
      ) : (
        <div>
          <p className="text-center text-black font-extrabold text-xl lg:text-4xl">
            Nothing to show please search something
          </p>
        </div>
      )}
    </div>
  );
};

export default Home;
